"""
Join sa3 sudo data with twitter data
"""
