"""
Blank init file for median data api module
"""
